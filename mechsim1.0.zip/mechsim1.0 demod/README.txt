Version 1.0 is the last version of mechsim.
Features of mechsim:
You can build a system of springs and masses  and change position of masses manually.
After that the simulation will show you how the system would respond to changes.
By pressing space button you can pause simulation and change the position of masses.
It is possible to observe system energy properties.
In simulation 1 meeter equals to one pixel.

Version 1.0 new features.
You can now define every masspoint mass properties and every spring properties.
You can start simulation only by loading special txt file.
You can find demo files in  archive  , 
so it would be easier to understand how the file should work.
You cannot make a quickstart ,like in previous versions.
Now it is possible  to change spring balanced length and starting distance between masspoints.

Tips on how to quickly start mechsim 1.0:
Unzip mechsim1.0.zip
Start mechsim1.0.jar
Press load data 
Choose one of demo files in this archive and load it.
Choose Simulation tab.
Try to click the red dot , change it's position and then watch the show.
Enjoy!
